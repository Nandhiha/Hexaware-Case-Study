import unittest
from dao.financerepository import FinanceRepository
from entity.user import User
from entity.expense import Expense
from exception.myexceptions import UserNotFoundException, ExpenseNotFoundException

class TestFinanceApp(unittest.TestCase):
    def setUp(self):
        self.repo = FinanceRepository()

    def test_create_user(self):
        user = User(user_id=101, username="test_user", email="test@example.com", password="pass123")
        result = self.repo.create_user(user)
        self.assertTrue(result)

    def test_add_expense(self):
        expense = Expense(expense_id=0, user_id=101, amount=200.0, category_id=1, date='2025-04-17', description='test expense')
        result = self.repo.add_expense(expense)
        self.assertTrue(result)

    def test_user_not_found_exception(self):
        with self.assertRaises(UserNotFoundException):
            self.repo.view_expenses_by_user_id(9999)

    def test_expense_not_found_exception(self):
        with self.assertRaises(ExpenseNotFoundException):
            self.repo.delete_expense(9999)

    def test_view_all_users(self):
        users = self.repo.view_all_users()
        self.assertIsInstance(users, list)

if __name__ == "__main__":
    unittest.main()



